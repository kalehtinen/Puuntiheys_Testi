package model;

public class ProListItem {

	private int id;

	private double tiheys;
	private String paksuus;
	private String pituus;
	private String leveys;
	private String paino;
	private String grain;

	public ProListItem() {

	}

	public ProListItem(double tiheys, String grain, String pituus, String leveys, String paino, String paksuus) {

		this.id = 0;
		this.tiheys = tiheys;
		this.paksuus = paksuus;
		this.pituus = pituus;
		this.leveys = leveys;
		this.paino = paino;
		this.grain = grain;
	}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public double getTiheys() {
		return tiheys;
	}

	public void setTiheys(double tiheys) {
		this.tiheys = tiheys;
	}

	public String getPaksuus() {
		return paksuus;
	}

	public void setPaksuus(String paksuus) {
		this.paksuus = paksuus;
	}

	public String getPituus() {
		return pituus;
	}

	public void setPituus(String pituus) {
		this.pituus = pituus;
	}

	public String getLeveys() {
		return leveys;
	}

	public void setLeveys(String leveys) {
		this.leveys = leveys;
	}

	public String getPaino() {
		return paino;
	}

	public void setPaino(String paino) {
		this.paino = paino;
	}

	public String getGrain() {
		return grain;
	}

	public void setGrain(String grain) {
		this.grain = grain;
	}

	@Override
	public String toString() {
		return "ProListItem [id=" + id + ", tiheys=" + tiheys + ", paksuus=" + paksuus + ", pituus" + pituus
				+ ", leveys=" + leveys + ", paino=" + paino + ", grain=" + grain + "]";
	}

}
