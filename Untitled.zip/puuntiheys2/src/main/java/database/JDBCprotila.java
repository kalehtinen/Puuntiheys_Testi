package database;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import model.ProListItem;

public class JDBCprotila implements ProListDao {

	database database;

	public JDBCprotila() {
		database = new database();
	}

	@Override
	public List<ProListItem> getAllItems() {
		List<ProListItem> items = new ArrayList<ProListItem>();
		Connection connection = database.connect();
		try {
			PreparedStatement statement = connection.prepareStatement("SELECT * FROM ProListItem");
			ResultSet results = statement.executeQuery();

			while (results.next()) {
				ProListItem item = new ProListItem();
				item.setId(results.getInt("id"));
				item.setTiheys(results.getDouble("tiheys"));
				item.setPituus(results.getString("pituus"));
				item.setLeveys(results.getString("leveys"));
				item.setPaino(results.getString("paino"));
				item.setGrain(results.getString("grain"));

				items.add(item);
			}
			results.close();
			statement.close();
			connection.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return items;
	}

	@Override
	public boolean addItem(ProListItem newItem) {
		Connection connection = database.connect();
		try {
			PreparedStatement statement = connection.prepareStatement(
					"INSERT INTO ProListItem(tiheys, grain, pituus, leveys, paino, paksuus) VALUES (?,?,?,?,?,?)",
					Statement.RETURN_GENERATED_KEYS);

			statement.setDouble(1, newItem.getTiheys());
			statement.setString(2, newItem.getGrain());
			statement.setString(3, newItem.getPituus());
			statement.setString(4, newItem.getLeveys());
			statement.setString(5, newItem.getPaino());
			statement.setString(6, newItem.getPaksuus());
			statement.executeUpdate();

			ResultSet keys = statement.getGeneratedKeys();
			if (keys.next()) {
				long id = keys.getLong(1);

			}
			keys.close();
			statement.close();
			connection.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public boolean removeItem(ProListItem item) {
		Connection connection = database.connect();
		try {
			PreparedStatement statement = connection.prepareStatement("DELETE FROM ProListItem WHERE id = ?");
			statement.setInt(1, item.getId());
			statement.executeUpdate();

			statement.close();
			connection.close();

		} catch (Exception e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
			return false;
		}
		return true;
	}

	@Override
	public ProListItem getItem(long id) {
		// TODO Auto-generated method stub
		return null;
	}

	public void createTable() {
		Connection connection = null;

		try {
			connection = database.connect();
			String sql = "CREATE TABLE IF NOT EXISTS ProListItem (id INTEGER PRIMARY KEY, tiheys TEXT, grain TEXT, "
					+ "paksuus TEXT, leveys TEXT, paino TEXT, pituus TEXT)";
			PreparedStatement s = connection.prepareStatement(sql);
			s.execute();
			connection.close();
		} catch (Exception e) {
			System.out.println("Virhe createTable");
		}
	}

}
